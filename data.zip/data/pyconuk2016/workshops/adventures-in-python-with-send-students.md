title: Adventures in Python with SEND students
speaker: hannah-mills
---
An interactive workshop about developing strategies for classes with a hugely diverse mixture of special needs in their make up. Come along to get some hands on experience of planning for students with special needs and go away with a toolkit of strategies you can use in your lessons!
