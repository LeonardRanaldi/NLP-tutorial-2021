title: 'Lessons learned from organizing SciPy Latin America 2016'
subtitle:
speaker: raniere-gaia-costa-da-silva
---
At the first semester of 2016 I was one of the organizers of SciPy Latin America 2016. During this time I learned some lessons about organizing events when you are 10,052 km far from the venue plus 4 hours ahead.