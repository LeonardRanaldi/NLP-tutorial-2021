title: 'Prisoners, Cooperation and Spatial Structure'
subtitle:
speaker: nikoleta-evdokia-glynatsi
---
The talk will be a brief introduction to Game Theory: the Prisoner's Dilemma,
the tournaments that have been carried out since 1980 and the Axelrod library.
Moreover, it will focus on my summer research which is on Spatial tournaments for the Iterated Prisoners Dilemma. It will mention some key points as to why spatial structure was chosen for further research.

My contribution to the Axelrod library will be shown and how the results where
analyzed and implemented.