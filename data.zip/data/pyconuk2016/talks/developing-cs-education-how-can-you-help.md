title: 'Developing CS education - how can you help'
subtitle:
speaker: laura-dixon
---
Many developers seem extremely keen to influence and help to improve CS education, however it is not always clear how best to help. I aim to highlight some misconceptions and provide some suggestions of how teachers and professionals can work together to achieve real results. 