title: 'Chat bots: What is AI?'
subtitle:
speaker: chloe-parkes
---
Artificial intelligence is a widely growing field, with so many uses. I'd like to talk about what Artificial intelligence is, and how it's being used throughout the industry. The focus will be around chat bots, using ones within the customer service areas as the main examples as well as the well known Clever bot.
I will also go through how they are written, which will be based on using Python, and AIML. 