title: "Taking the robot out of Mr. Robot or: Why tech sucks & how you can help to make it better"
subtitle:
speaker: kerstin-kollmann
---
Not everything about the tech industry is as "cool" as it is sometimes made out
to be – by the media, representations in fiction or indeed members of the tech
community themselves – though not everyone is equally aware of how or why it is
more difficult "to tech" for some than it is for others, regardless of innate
talent or skills.

In my talk I want to point out some of the barriers which make it harder or
less fun for some of us to participate and how everyone can contribute to
making tech a little more welcoming for everyone else. (& I might use examples
from your new favourite fictional texts while I'm at it.)
