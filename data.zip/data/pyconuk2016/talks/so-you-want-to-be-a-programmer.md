title: 'So, you want to be a programmer'
subtitle:
speaker: daniele-marco-procida
---
A talk aimed at visiting school pupils on the open day