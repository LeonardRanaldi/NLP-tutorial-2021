title: "Life as the Sourcerer's Apprentice"
subtitle:
speaker: eva-gonzalez
---
A quick (and by no means complete) guide to what recruiters look for in CV's and the hiring process.