title: 'Why do kids need to code and how can we help?'
subtitle:
speaker: cat-lamin
---
I want to talk about the issues facing teachers today with the introduction of the new computing curriculum. I want to talk about my own experiences in the primary classroom and how people in the Python community can help and support teachers to achieve the best they can