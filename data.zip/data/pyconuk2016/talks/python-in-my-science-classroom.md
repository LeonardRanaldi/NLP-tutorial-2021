title: 'Python in my Science Classroom'
subtitle:
speaker: praveen-patil
---
Python programming language has the potential to change a dull teaching learning process in to more stimulating active learning. Equations in physics and maths always look dull and boring. With the power of python one can see the beauty behind those equations and can find real world connections. With the effective use of python programs a teacher can actively engage the students and help them visualize the concepts and have better understanding.

In this presentation I will talk about my teaching experiments with Python in Physics with live demo of some scientific python programs. I will also demonstrate some science experiments using python, ExpEYES and PSLab. These are python powered open source lab interfaces which are aimed at providing affordable open source lab equipment to enable students to learn by exploring and experimenting.