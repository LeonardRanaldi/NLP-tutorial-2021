title: 'My journey from wxPython to PyQt'
subtitle:
speaker: barry-scott
---
I used to use wxPython for all my GUI work but I now use PyQt5 and will share why I made the change, the approach I took and difficulties encountered.
